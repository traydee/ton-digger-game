// Internal imports
import {
  getCustomProperty,
  setCustomProperty,
  incrementCustomProperty,
} from "./updateCustomProperty.js";

// Global variables
const JUMP_SPEED = window.innerWidth > 768 ? 0.4 : 0.3;
const GRAVITY = window.innerWidth > 768 ? 0.0015 : 0.0009;

// Elements
const characterElem = document.querySelector("[data-character]");

// Variables
let isJumping;
let yVelocity;

// Setup character
const setupCharacter = () => {
  // Set variable initial values
  isJumping = false;
  yVelocity = 0;

  // Set custom properties
  if (window.innerWidth > 1024) {
    setCustomProperty(characterElem, "--bottom", 8.5);
  } else {
    setCustomProperty(characterElem, "--bottom", 5);
  }

  // Remove and add event listeners
  document.removeEventListener("keydown", onJump);
  document.addEventListener("keydown", onJump);

  // Set character running image
  characterElem.src = "./assets/images/character-running.png";
  characterElem.style.transform = "scale(0.8)";
};

// Update character
const updateCharacter = (delta) => {
  handleRun();
  handleJump(delta);
};

// Get character rect
const getCharacterRect = () => {
  return characterElem.getBoundingClientRect();
};

// Set character lose
const setCharacterLose = () => {
  characterElem.src = "./assets/images/character-standing.png";
};

// Handle run
const handleRun = () => {
  // Check if jumping
  if (isJumping) {
    characterElem.src = "./assets/images/character-standing.png";

    return;
  }
};

// Handle jump
const handleJump = (delta) => {
  // If not jumping return
  if (!isJumping) return;

  // Increment custom property
  incrementCustomProperty(characterElem, "--bottom", yVelocity * delta);

  // Check if the jump is finished
  if (window.innerWidth > 1024) {
    if (getCustomProperty(characterElem, "--bottom") <= 8.5) {
      setCustomProperty(characterElem, "--bottom", 8.5);

      isJumping = false;
      characterElem.src = "./assets/images/character-running.png";
    }
  } else {
    if (getCustomProperty(characterElem, "--bottom") <= 5) {
      setCustomProperty(characterElem, "--bottom", 5);

      isJumping = false;
      characterElem.src = "./assets/images/character-running.png";
    }
  }

  // Decrease y velocity
  yVelocity -= GRAVITY * delta;
};

// On jump
const onJump = (e) => {
  if (e.code !== "Space" || isJumping) return;

  yVelocity = JUMP_SPEED;
  isJumping = true;
};

// Export
export {
  setupCharacter,
  updateCharacter,
  getCharacterRect,
  setCharacterLose,
  onJump,
};
