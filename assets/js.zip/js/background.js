// Internal imports
import {
  getCustomProperty,
  setCustomProperty,
  incrementCustomProperty,
} from "./updateCustomProperty.js";

// Global variables
const SPEED = window.innerWidth > 768 ? 0.005 : 0.0075;

// Elements
const backgroundElems = document.querySelectorAll("[data-background]");

// Setup background
const setupBackground = () => {
  setCustomProperty(backgroundElems[0], "--left", 0);
  setCustomProperty(backgroundElems[1], "--left", 100);
};

// Update background
const updateBackground = (delta, speedScale) => {
  backgroundElems.forEach((background) => {
    incrementCustomProperty(
      background,
      "--left",
      delta * speedScale * SPEED * -1
    );

    // Check and update --left of background
    if (getCustomProperty(background, "--left") <= -100) {
      incrementCustomProperty(background, "--left", 200);
    }
  });
};

// Export
export { setupBackground, updateBackground };
